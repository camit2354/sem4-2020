// Demonstrate TreeSet.
import java.util.*;
   
class clsTreetSet {
  public static void main(String args[]) 
  {
   
    TreeSet<String> ts = new TreeSet<String>();
    ts.add("3");
    ts.add("2");
    ts.add("1");
    ts.add("5");
    ts.add("7");
    ts.add("6");
   
    System.out.println(ts);
  }
}
