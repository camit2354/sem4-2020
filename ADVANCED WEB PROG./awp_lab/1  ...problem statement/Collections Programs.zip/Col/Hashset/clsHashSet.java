// Hashset sample code 
import java.util.*;
class clsHashSet 
{
  public static void main(String args[]) 
  {
    // Create a hash set.
    HashSet<String> objHash = new HashSet<String>();

    // Add elements to the hash set.
    objHash.add("1");
    objHash.add("2");
    objHash.add("3");
    objHash.add("4");
    objHash.add("5");
    objHash.add("6");

    // Display the Hash results
    System.out.println(objHash);
  }
}
